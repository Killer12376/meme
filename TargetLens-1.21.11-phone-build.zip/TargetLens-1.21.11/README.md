# TargetLens for Minecraft Java 1.21.11

A lightweight Fabric target HUD inspired by the target information feature in FastClient HUD. It shows the entity under your crosshair in a compact panel with:

- Entity/player name
- Current and maximum health
- A color-changing health bar
- An `INVIS` marker when the client knows the entity is invisible

The mod checks Minecraft's crosshair result first. If needed, it ray-checks nearby tracked living entities. The fallback ray is limited by blocks and entities already hit along the view ray, so it does not intentionally target through walls.

## Important limits

This is an independent recreation of the target HUD feature, not a copy of FastClient's code or complete interface. It has not been compiled or tested in this environment. The first cloud build might reveal API or Gradle errors that need fixing.

A client-side mod only knows about entities and health values sent to it by the server. It cannot reveal players that the server does not send to the client, or recover health information the server hides. The `INVIS` marker only appears when the client receives the entity's invisibility state.

## Requirements

- Minecraft Java 1.21.11
- Fabric Loader 0.18.1 or newer
- Fabric API for Minecraft 1.21.11
- Java 21 (for building)

## Build from your phone with GitHub Actions

You do not need a PC. GitHub's cloud runner builds the mod for you.

1. Create a repository on GitHub.
2. Upload every file and folder from this project into the repository's root. Keep the `.github/workflows/build.yml` file and its folders.
3. Open the repository's **Actions** tab.
4. Select **Build TargetLens**, then choose **Run workflow**. If the workflow does not appear, open the **Actions** tab and enable workflows for the repository.
5. Open the finished workflow run. Under **Artifacts**, download `targetlens-1.21.11`.
6. Extract the downloaded artifact ZIP. It contains `targetlens-1.0.0.jar` (and possibly a sources JAR).
7. Put `targetlens-1.0.0.jar` in your Minecraft 1.21.11 Fabric instance's `mods` folder. Keep Fabric API installed.

If the workflow fails, open the run and copy the first red error section. The source has not been verified by a successful build yet.

## Build locally

With Java 21 and Gradle installed, run `gradle build --no-daemon` in the project folder. The mod JAR is written to `build/libs/`.
