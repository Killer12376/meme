package dev.targetlens;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;

/**
 * Client-side target HUD. It first uses Minecraft's normal crosshair result, then
 * performs a short, block-limited entity ray check so tracked invisible entities
 * still receive a target panel even when their model is not rendered.
 */
public final class TargetLensClient implements ClientModInitializer {
    private static final double TARGET_REACH = 6.0D;
    private static final int PANEL_WIDTH = 172;
    private static final int PANEL_HEIGHT = 45;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
                ResourceLocation.fromNamespaceAndPath("targetlens", "target_hud"),
                this::renderTargetHud
        );
    }

    private void renderTargetHud(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || client.screen != null || client.options.hideGui) {
            return;
        }

        LivingEntity target = findTarget(client);
        if (target == null || !target.isAlive()) {
            return;
        }

        float maxHealth = target.getMaxHealth();
        float health = target.getHealth();
        if (!Float.isFinite(maxHealth) || maxHealth <= 0.0F || !Float.isFinite(health)) {
            return;
        }

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        int x = (screenWidth - PANEL_WIDTH) / 2;
        int y = Math.min(screenHeight - PANEL_HEIGHT - 4, screenHeight / 2 + 13);
        if (y < 4) {
            y = 4;
        }

        // Compact dark panel, with a thin border. The panel stays near the crosshair.
        graphics.fill(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xD9101420);
        graphics.fill(x, y, x + PANEL_WIDTH, y + 1, 0xFF68758B);
        graphics.fill(x, y + PANEL_HEIGHT - 1, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xFF68758B);
        graphics.fill(x, y, x + 1, y + PANEL_HEIGHT, 0xFF68758B);
        graphics.fill(x + PANEL_WIDTH - 1, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xFF68758B);

        String name = target.getDisplayName().getString();
        int maxNameWidth = target.isInvisible() ? PANEL_WIDTH - 66 : PANEL_WIDTH - 16;
        name = trimToWidth(name, client.font, maxNameWidth);
        graphics.drawString(client.font, name, x + 8, y + 6, 0xFFFFFFFF, true);

        if (target.isInvisible()) {
            graphics.drawString(client.font, "INVIS", x + PANEL_WIDTH - 43, y + 6, 0xFFFFC76A, true);
        }

        String healthText = "HP " + oneDecimal(health) + " / " + oneDecimal(maxHealth);
        graphics.drawString(client.font, healthText, x + 8, y + 19, healthColor(health, maxHealth), true);

        int barX = x + 8;
        int barY = y + 33;
        int barWidth = PANEL_WIDTH - 16;
        graphics.fill(barX, barY, barX + barWidth, barY + 5, 0xFF303744);
        float ratio = Math.max(0.0F, Math.min(1.0F, health / maxHealth));
        int filledWidth = Math.round(barWidth * ratio);
        if (filledWidth > 0) {
            graphics.fill(barX, barY, barX + filledWidth, barY + 5, healthBarColor(ratio));
        }
    }

    private static LivingEntity findTarget(Minecraft client) {
        Entity self = client.player;
        HitResult crosshair = client.hitResult;

        // Use vanilla's exact result whenever it already picked a living entity.
        if (crosshair instanceof EntityHitResult entityHit
                && entityHit.getEntity() instanceof LivingEntity living
                && living != self
                && living.isAlive()
                && self.distanceTo(living) <= TARGET_REACH) {
            return living;
        }

        // Otherwise ray-check tracked living entities. This also works if the
        // entity is tracked by the client but its invisible model is not drawn.
        Vec3 start = client.player.getEyePosition();
        Vec3 direction = client.player.getViewVector(1.0F);
        double allowedDistance = TARGET_REACH;

        // Never select through a block. If vanilla hit a block, cap the ray at it.
        if (crosshair instanceof BlockHitResult blockHit) {
            allowedDistance = Math.min(allowedDistance, start.distanceTo(blockHit.getLocation()));
        } else if (crosshair instanceof EntityHitResult entityHit) {
            // Do not select a living entity behind another entity directly on the ray.
            allowedDistance = Math.min(allowedDistance, start.distanceTo(entityHit.getLocation()));
        }
        if (allowedDistance <= 0.0D) {
            return null;
        }

        Vec3 end = start.add(direction.scale(allowedDistance));
        List<LivingEntity> candidates = client.level.getEntitiesOfClass(
                LivingEntity.class,
                client.player.getBoundingBox().inflate(TARGET_REACH),
                entity -> entity != self && entity.isAlive() && entity.isPickable()
        );

        LivingEntity nearest = null;
        double nearestDistance = allowedDistance + 0.001D;
        for (LivingEntity candidate : candidates) {
            Optional<Vec3> intercept = candidate.getBoundingBox().inflate(candidate.getPickRadius()).clip(start, end);
            if (intercept.isEmpty()) {
                continue;
            }

            double distance = start.distanceTo(intercept.get());
            if (distance < nearestDistance && distance <= allowedDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private static String trimToWidth(String value, net.minecraft.client.gui.Font font, int maxWidth) {
        if (font.width(value) <= maxWidth) {
            return value;
        }
        String ellipsis = "…";
        String shortened = value;
        while (!shortened.isEmpty() && font.width(shortened + ellipsis) > maxWidth) {
            shortened = shortened.substring(0, shortened.length() - 1);
        }
        return shortened + ellipsis;
    }

    private static String oneDecimal(float value) {
        // Avoid Formatter allocations on every HUD frame.
        return Float.toString(Math.round(value * 10.0F) / 10.0F);
    }

    private static int healthColor(float health, float maxHealth) {
        float ratio = Math.max(0.0F, Math.min(1.0F, health / maxHealth));
        return ratio > 0.6F ? 0xFF8DF0A4 : ratio > 0.3F ? 0xFFFFD479 : 0xFFFF7777;
    }

    private static int healthBarColor(float ratio) {
        return ratio > 0.6F ? 0xFF37C96B : ratio > 0.3F ? 0xFFFFB936 : 0xFFE84C4C;
    }
}
